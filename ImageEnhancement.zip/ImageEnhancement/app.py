import os
import numpy as np
import tensorflow as tf
from tensorflow import keras
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
from PIL import Image
import io
import base64

# Initialize Flask app
app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Model class definition (based on your existing code)
class ZeroDCE(keras.Model):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.dce_model = self.build_dce_net()

    def build_dce_net(self):
        input_img = keras.Input(shape=[None, None, 3])
        conv1 = keras.layers.Conv2D(32, (3, 3), strides=(1, 1), activation="relu", padding="same")(input_img)
        conv2 = keras.layers.Conv2D(32, (3, 3), strides=(1, 1), activation="relu", padding="same")(conv1)
        conv3 = keras.layers.Conv2D(32, (3, 3), strides=(1, 1), activation="relu", padding="same")(conv2)
        conv4 = keras.layers.Conv2D(32, (3, 3), strides=(1, 1), activation="relu", padding="same")(conv3)
        int_con1 = keras.layers.Concatenate(axis=-1)([conv4, conv3])
        conv5 = keras.layers.Conv2D(32, (3, 3), strides=(1, 1), activation="relu", padding="same")(int_con1)
        int_con2 = keras.layers.Concatenate(axis=-1)([conv5, conv2])
        conv6 = keras.layers.Conv2D(32, (3, 3), strides=(1, 1), activation="relu", padding="same")(int_con2)
        int_con3 = keras.layers.Concatenate(axis=-1)([conv6, conv1])
        x_r = keras.layers.Conv2D(24, (3, 3), strides=(1, 1), activation="tanh", padding="same")(int_con3)
        return keras.Model(inputs=input_img, outputs=x_r)

    def get_enhanced_image(self, data, output):
        r1 = output[:, :, :, :3]
        r2 = output[:, :, :, 3:6]
        r3 = output[:, :, :, 6:9]
        r4 = output[:, :, :, 9:12]
        r5 = output[:, :, :, 12:15]
        r6 = output[:, :, :, 15:18]
        r7 = output[:, :, :, 18:21]
        r8 = output[:, :, :, 21:24]
        x = data + r1 * (tf.square(data) - data)
        x = x + r2 * (tf.square(x) - x)
        x = x + r3 * (tf.square(x) - x)
        enhanced_image = x + r4 * (tf.square(x) - x)
        x = enhanced_image + r5 * (tf.square(enhanced_image) - enhanced_image)
        x = x + r6 * (tf.square(x) - x)
        x = x + r7 * (tf.square(x) - x)
        enhanced_image = x + r8 * (tf.square(x) - x)
        return enhanced_image

    def call(self, data):
        dce_net_output = self.dce_model(data)
        return self.get_enhanced_image(data, dce_net_output)

# Load the model (executed when app starts)
def load_model():
    #print("Loading Zero-DCE model...")
    model = ZeroDCE()
    # Create a dummy input to build the model
    dummy_input = tf.ones((1, 64, 64, 3))
    _ = model(dummy_input)
    # Load the weights
    model.load_weights('modelZeroDCE.h5')
    print("Model loaded successfully!")
    return model

# Global model instance
model = load_model()

@app.route('/')
def home():
    return jsonify({'message': 'Welcome to the Zero-DCE API! Use /enhance or /enhance-file to process images.'})

@app.route('/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'message': 'Zero-DCE API is running'})

@app.route('/enhance', methods=['POST'])
def enhance_image():
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400
    
    try:
        # Get the image from the request
        image_file = request.files['image']
        image = Image.open(image_file)
        
        # Preprocess the image
        img_array = keras.utils.img_to_array(image)
        img_array = img_array.astype("float32") / 255.0
        img_array = np.expand_dims(img_array, axis=0)
        
        # Perform inference
        enhanced_array = model(img_array)
        enhanced_array = tf.cast((enhanced_array[0, :, :, :] * 255), dtype=np.uint8)
        enhanced_image = Image.fromarray(enhanced_array.numpy())
        
        # Convert enhanced image to base64 string
        buffered = io.BytesIO()
        enhanced_image.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode('utf-8')
        
        return jsonify({
            'status': 'success', 
            'enhanced_image': img_str
        })
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/enhance-file', methods=['POST'])
def enhance_file():
    """Alternative endpoint that returns the image file directly"""
    if 'image' not in request.files:
        return jsonify({'error': 'No image provided'}), 400
    
    try:
        # Get the image from the request
        image_file = request.files['image']
        image = Image.open(image_file)
        
        # Preprocess the image
        img_array = keras.utils.img_to_array(image)
        img_array = img_array.astype("float32") / 255.0
        img_array = np.expand_dims(img_array, axis=0)
        
        # Perform inference
        enhanced_array = model(img_array)
        enhanced_array = tf.cast((enhanced_array[0, :, :, :] * 255), dtype=np.uint8)
        enhanced_image = Image.fromarray(enhanced_array.numpy())
        
        # Send the image directly
        img_io = io.BytesIO()
        enhanced_image.save(img_io, 'PNG')
        img_io.seek(0)
        
        return send_file(img_io, mimetype='image/png')
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Get port from environment variable or use 5000 as default
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)


